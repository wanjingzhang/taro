module.exports = require('./dist/index.js').default
module.exports.default = module.exports
