// 字符串简写
export const enum Shortcuts {
  Container = 'container',
  Childnodes = 'cn',
  Text = 'v',
  NodeType = 'nt',
  NodeName = 'nn',

  // Attrtibutes
  Style = 'st',
  Class = 'cl',
  Src = 'src'
}
