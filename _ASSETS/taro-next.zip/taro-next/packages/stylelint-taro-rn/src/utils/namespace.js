const prefix = 'taro-rn'

export function namespace (ruleName) {
  return `${prefix}/${ruleName}`
}
