export const isString = string => typeof string === 'string'
