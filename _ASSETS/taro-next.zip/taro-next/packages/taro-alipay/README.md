# `@tarojs/plugin-platform-alipay`

Taro 插件。用于支持编译为支付宝小程序。
