module.exports = require('./dist/index.js').default
module.exports.default = module.exports
module.exports.Alipay = require('./dist/index.js').Alipay
