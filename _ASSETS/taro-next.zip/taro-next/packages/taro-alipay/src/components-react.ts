// For React.createElement's type
export * from '@tarojs/components/mini'
export const Lottie = 'lottie'
export const Lifestyle = 'lifestyle'
export const LifeFollow = 'life-follow'
export const ContactButton = 'contact-button'
