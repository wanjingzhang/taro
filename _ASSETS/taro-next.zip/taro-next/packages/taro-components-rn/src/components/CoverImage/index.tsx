export { default } from '../Image'
