import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  camera: {
    width: 300,
    height: 300
  }
})
