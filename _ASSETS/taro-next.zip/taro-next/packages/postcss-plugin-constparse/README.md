# `postcss-plugin-constparse`

在 H5 环境中 `tabbar` 的高度固定在 50px。
