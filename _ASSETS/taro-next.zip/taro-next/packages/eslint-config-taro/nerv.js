module.exports = Object.assign({}, require('./index'), {
  settings: {
    react: {
      pragma: 'Nerv',
      version: '15.0'
    }
  }
})
