module.exports = Object.assign({}, require('./index'), {
  settings: {
    react: {
      pragma: 'React',
      version: 'detect'
    }
  }
})
