module.exports = Object.assign({}, require('./react'))
