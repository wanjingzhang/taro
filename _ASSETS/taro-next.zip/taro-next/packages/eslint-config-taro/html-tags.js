// elements-of-html
// https://github.com/w3c/elements-of-html

module.exports = [
  {
    element: 'select',
    message: '请使用 Picker 组件代替 <select>'
  }
]
