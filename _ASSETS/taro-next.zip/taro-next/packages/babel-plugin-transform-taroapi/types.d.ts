declare module '@tarojs/taro-h5/dist/taroApis' {
  export const apis: {
    [key: string]: boolean
  }
}
