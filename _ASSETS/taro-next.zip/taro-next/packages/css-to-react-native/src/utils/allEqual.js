export const allEqual = arr => arr.every(v => v === arr[0])
