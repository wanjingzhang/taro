export const values = obj => Object.keys(obj).map(key => obj[key])
