export interface IErrorLine {
  desc: string;
  valid: boolean;
  solution?: string;
}
