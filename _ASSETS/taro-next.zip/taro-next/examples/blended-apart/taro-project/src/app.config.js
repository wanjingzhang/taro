export default {
  pages: [
    'pages/index/index'
  ]
}
