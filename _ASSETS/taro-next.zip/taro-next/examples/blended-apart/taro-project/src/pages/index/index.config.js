export default {
  navigationBarTitleText: 'Taro 分包页'
}
