module.exports = { whoami: 'Wechat MiniProgram' }
