export default {
  navigationBarTitleText: '首页',
  usingComponents: {
    'avatar': 'plugin://myPlugin/avatar',
    "mp-comp": "../../component/comp"
  }
}
