export default {
  "componentGenerics": {
    "mp-comp": true
  }
}
