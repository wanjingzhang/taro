export default {
  navigationBarTitleText: '测试页'
}
