import React, { Component } from 'react'
import { View } from '@tarojs/components'

import './index.scss'

export default class Index extends Component {
  render () {
    return (
      <View className='blue'>Detail</View>
    )
  }
}
