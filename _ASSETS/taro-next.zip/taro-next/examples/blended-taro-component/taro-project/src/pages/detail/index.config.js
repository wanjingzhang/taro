export default {
  navigationBarTitleText: 'Detail'
}
