export default {
  pages: [
    'pages/index/index',
    'pages/detail/index',
  ],
  components: [
    'pages/detail/index',
    'components/picker/index'
  ]
}
