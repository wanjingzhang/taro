export default {
  navigationBarTitleText: 'Picker',
  styleIsolation: 'isolated',
  virtualHost: true
}
