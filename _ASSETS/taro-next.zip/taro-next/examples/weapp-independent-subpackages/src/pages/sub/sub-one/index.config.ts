export default {
  navigationBarTitleText: '独立分包'
}
