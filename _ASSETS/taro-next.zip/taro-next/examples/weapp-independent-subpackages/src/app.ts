export default function (props) {
  return props.children
}
