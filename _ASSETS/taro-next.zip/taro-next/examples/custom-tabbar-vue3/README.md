## Demo - 微信小程序自定义 TabBar（Vue3）

Taro 微信小程序自定义 TabBar 开发文档：https://docs.taro.zone/docs/miniprogram-plugin
微信小程序自定义 TabBar 文档：https://developers.weixin.qq.com/miniprogram/dev/framework/ability/custom-tabbar.html

### 介绍

本示例演示了如何使用 Vue3 编写微信小程序的自定义 TabBar 组件，并使用了 Vuex 去管理 TabBar 的状态。
