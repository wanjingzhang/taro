<template>
  <view class="index">
    <text>我是首页！</text>
  </view>
</template>

<script>
export default {
  name: 'Index'
}
</script>
