<template>
  <view class="index">
    <text>我是分类页！</text>
  </view>
</template>

<script setup>
</script>
