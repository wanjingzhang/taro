<template>
  <view class="index">
    <text>我是个人中心！</text>
  </view>
</template>

<script setup>
</script>
