<template>
  <view class="index">
    <text>我是购物车！</text>
  </view>
</template>

<script>
export default {
  name: 'Cart'
}
</script>
