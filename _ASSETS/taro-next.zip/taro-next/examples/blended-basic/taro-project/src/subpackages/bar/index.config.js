export default {
  navigationBarTitleText: 'bar'
}
