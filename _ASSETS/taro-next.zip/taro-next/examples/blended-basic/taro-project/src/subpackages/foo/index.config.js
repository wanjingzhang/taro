export default {
  navigationBarTitleText: 'foo'
}
