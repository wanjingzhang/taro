export function printCommon () {
  console.log('I should be in main package')
}
