export default {
  navigationBarTitleText: '首页',
  usingComponents: {
    title: '@/components/title/index'
  }
}
