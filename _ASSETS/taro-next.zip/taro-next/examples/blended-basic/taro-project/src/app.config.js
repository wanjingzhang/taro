export default {
  pages: [
    'pages/index/index',
    'subpackages/bar/index',
    'subpackages/foo/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: 'WeChat',
    navigationBarTextStyle: 'black'
  }
}
