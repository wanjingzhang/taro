Component({
  data: {
    title: "Hello World"
  }
})