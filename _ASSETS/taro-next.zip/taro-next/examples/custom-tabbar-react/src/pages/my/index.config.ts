export default definePageConfig({
  navigationBarTitleText: '个人中心',
  "usingComponents": {}
})
