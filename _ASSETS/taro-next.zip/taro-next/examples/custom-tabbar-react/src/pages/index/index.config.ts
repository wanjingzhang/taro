export default definePageConfig({
  navigationBarTitleText: '首页',
  "usingComponents": {}
})
