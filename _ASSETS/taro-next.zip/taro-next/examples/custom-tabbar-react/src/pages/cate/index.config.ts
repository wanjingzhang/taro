export default definePageConfig({
  navigationBarTitleText: '分类页',
  "usingComponents": {}
})
