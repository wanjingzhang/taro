export default {
  "component": true
}
