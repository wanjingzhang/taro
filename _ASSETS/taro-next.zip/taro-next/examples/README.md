## Examples

收录了一系列 Taro 的例子。

- build-weapp-plugin: 开发微信小程序插件
- blended-basic: 在原生小程序项目中使用 Taro 生成的页面
- blended-apart: 把 Taro 项目作为原生项目中的一个分包单独使用
- blend-taro-component: 把 Taro 项目编译为原生自定义组件
- weapp-independent-subpackages: 微信小程序独立分包功能演示
- custom-tabbar-react: 微信小程序自定义 TabBar（React）
- custom-tabbar-vue3: 微信小程序自定义 TabBar（Vue3）
