# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 3.3.9   | [Security fix for ReDoS](https://github.com/NervJS/taro/pull/10210) |

## Reporting a Vulnerability

People are welcomed to report a vulnerability by sending an Email to **taro@jd.com** or **taro_dev@jd.com**.Also PR or Issues are welcomed too.

Vulnerability will be fixed and publish in one or two weeks.
