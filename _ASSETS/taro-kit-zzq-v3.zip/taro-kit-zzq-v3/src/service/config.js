// https://api.github.com/repos/NervJS/taro/issues?per_page=1&page=2
// export base = "http://api.shudong.wang/v1/"

export const base = "https://api.github.com/repos/"
