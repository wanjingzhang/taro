## 更新到Taro v1.3.9
> Taro v1.3.9

## 2018年11月26日
优化action 代码
