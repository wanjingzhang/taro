import { combineReducers } from 'redux'
import common from './common/common'

export default combineReducers({
  common,
})