
const initSate = {
  commonData: +new Date(),
}

export default initSate