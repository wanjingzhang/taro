export const TYPE_PRE_MONTH = -1

export const TYPE_NOW_MONTH = 0

export const TYPE_NEXT_MONTH = 1
