/* eslint-disable react/no-find-dom-node */
describe('Calendar Snap', () => {
  it('initial Calendar', () => {})
})
