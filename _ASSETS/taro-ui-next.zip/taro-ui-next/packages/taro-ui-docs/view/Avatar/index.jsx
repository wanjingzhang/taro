import React from 'react'
import AvatarDoc from '@md/avatar.md'

class AvatarView extends React.Component {
  render() {
    return <AvatarDoc />
  }
}

export default AvatarView
