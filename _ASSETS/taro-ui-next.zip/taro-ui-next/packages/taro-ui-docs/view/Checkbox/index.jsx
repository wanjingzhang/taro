import React from 'react'
import CheckboxDoc from '@md/checkbox.md'

class CheckboxView extends React.Component {
  render() {
    return <CheckboxDoc />
  }
}

export default CheckboxView
