import React from 'react'
import SliderDoc from '@md/slider.md'

class SliderView extends React.Component {
  render() {
    return <SliderDoc />
  }
}

export default SliderView
