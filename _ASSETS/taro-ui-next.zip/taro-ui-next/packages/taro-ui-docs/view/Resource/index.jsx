import React from 'react'
import ResourceDoc from '@md/resource.md'

class Resource extends React.Component {
  render() {
    return <ResourceDoc />
  }
}

export default Resource
