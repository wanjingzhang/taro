import React from 'react'
import ActionSheetDoc from '@md/action-sheet.md'

class ActionSheetView extends React.Component {
  render() {
    return <ActionSheetDoc />
  }
}

export default ActionSheetView
