import React from 'react'
import IconDoc from '@md/icon.md'

class IconView extends React.Component {
  render() {
    return <IconDoc />
  }
}

export default IconView
