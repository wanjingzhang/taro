import React from 'react'
import NavBarDoc from '@md/navbar.md'

class NavBarView extends React.Component {
  render() {
    return <NavBarDoc />
  }
}

export default NavBarView
