import React from 'react'
import TagDoc from '@md/tag.md'

class TagView extends React.Component {
  render() {
    return <TagDoc />
  }
}

export default TagView
