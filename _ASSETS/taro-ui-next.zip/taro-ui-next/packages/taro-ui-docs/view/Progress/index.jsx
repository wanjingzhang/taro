import React from 'react'
import ProgressDoc from '@md/progress.md'

class ProgressView extends React.Component {
  render() {
    return <ProgressDoc />
  }
}

export default ProgressView
