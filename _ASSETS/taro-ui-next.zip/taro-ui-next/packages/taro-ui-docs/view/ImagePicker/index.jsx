import React from 'react'
import ImagePickerDoc from '@md/image-picker.md'

class ImagePickerView extends React.Component {
  render() {
    return <ImagePickerDoc />
  }
}

export default ImagePickerView
