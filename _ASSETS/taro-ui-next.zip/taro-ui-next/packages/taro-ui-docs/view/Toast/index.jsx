import React from 'react'
import ToastDoc from '@md/toast.md'

class ToastView extends React.Component {
  render() {
    return <ToastDoc />
  }
}

export default ToastView
