import React from 'react'
import AccordionDoc from '@md/accordion.md'

class AccordionView extends React.Component {
  render() {
    return <AccordionDoc />
  }
}

export default AccordionView
