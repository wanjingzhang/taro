import React from 'react'
import FloatLayoutDoc from '@md/float-layout.md'

class FloatLayoutView extends React.Component {
  render() {
    return <FloatLayoutDoc />
  }
}

export default FloatLayoutView
