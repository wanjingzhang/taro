import React from 'react'
import PickerDoc from '@md/picker.md'

class PickerView extends React.Component {
  render() {
    return <PickerDoc />
  }
}

export default PickerView
