import React from 'react'
import FabDoc from '@md/fab.md'

class FabView extends React.Component {
  render() {
    return <FabDoc />
  }
}

export default FabView
