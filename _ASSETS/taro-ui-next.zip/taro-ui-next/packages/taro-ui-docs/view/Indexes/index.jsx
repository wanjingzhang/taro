import React from 'react'
import IndexesDoc from '@md/indexes.md'

class IndexesView extends React.Component {
  render() {
    return <IndexesDoc />
  }
}

export default IndexesView
