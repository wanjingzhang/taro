import React from 'react'
import ActivityIndicatorDoc from '@md/activity-indicator.md'

class ActivityIndicatorView extends React.Component {
  render() {
    return <ActivityIndicatorDoc />
  }
}

export default ActivityIndicatorView
