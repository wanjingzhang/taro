import React from 'react'
import FormDoc from '@md/form.md'

class FormView extends React.Component {
  render() {
    return <FormDoc />
  }
}

export default FormView
