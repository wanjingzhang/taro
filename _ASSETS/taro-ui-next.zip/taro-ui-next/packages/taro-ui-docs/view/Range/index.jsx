import React from 'react'
import RangeDoc from '@md/range.md'

class RangeView extends React.Component {
  render() {
    return <RangeDoc />
  }
}

export default RangeView
