import React from 'react'
import IntroductionDoc from '@md/introduction.md'

class IntroductionView extends React.Component {
  render() {
    return <IntroductionDoc />
  }
}

export default IntroductionView
