import React from 'react'
import SwiperDoc from '@md/swiper.md'

class SwiperView extends React.Component {
  render() {
    return <SwiperDoc />
  }
}

export default SwiperView
