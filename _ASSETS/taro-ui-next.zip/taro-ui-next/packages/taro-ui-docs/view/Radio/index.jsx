import React from 'react'
import RadioDoc from '@md/radio.md'

class RadioView extends React.Component {
  render() {
    return <RadioDoc />
  }
}

export default RadioView
