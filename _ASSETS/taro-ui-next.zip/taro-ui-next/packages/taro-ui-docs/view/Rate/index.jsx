import React from 'react'
import RateDoc from '@md/rate.md'

class RateView extends React.Component {
  render() {
    return <RateDoc />
  }
}

export default RateView
