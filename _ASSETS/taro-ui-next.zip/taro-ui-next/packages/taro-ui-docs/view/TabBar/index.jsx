import React from 'react'
import TabBarDoc from '@md/tabbar.md'

class TabBarView extends React.Component {
  render() {
    return <TabBarDoc />
  }
}

export default TabBarView
