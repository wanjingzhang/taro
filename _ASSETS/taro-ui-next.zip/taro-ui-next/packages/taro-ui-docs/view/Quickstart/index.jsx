import React from 'react'
import QuickStartDoc from '@md/quickstart.md'

class QuickStartView extends React.Component {
  render() {
    return <QuickStartDoc />
  }
}

export default QuickStartView
