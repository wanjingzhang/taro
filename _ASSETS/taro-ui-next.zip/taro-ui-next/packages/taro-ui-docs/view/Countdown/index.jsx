import React from 'react'
import CountdownDoc from '@md/countdown.md'

class CountdownView extends React.Component {
  render() {
    return <CountdownDoc />
  }
}

export default CountdownView
