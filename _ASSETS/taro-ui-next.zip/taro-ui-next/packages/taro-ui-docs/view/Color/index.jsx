import React from 'react'
import ColorDoc from '@md/color.md'

import './style.scss'

class ColorView extends React.Component {
  render() {
    return <ColorDoc />
  }
}

export default ColorView
