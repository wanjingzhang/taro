import React from 'react'
import CurtainDoc from '@md/curtain.md'

class CurtainView extends React.Component {
  render() {
    return <CurtainDoc />
  }
}

export default CurtainView
