import React from 'react'
import CustomizeThemeDoc from '@md/customize-theme.md'

class CustomizeThemeView extends React.Component {
  render() {
    return <CustomizeThemeDoc />
  }
}

export default CustomizeThemeView
