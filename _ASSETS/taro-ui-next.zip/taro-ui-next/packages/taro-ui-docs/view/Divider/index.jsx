import React from 'react'
import DividerDoc from '@md/divider.md'

class DividerView extends React.Component {
  render() {
    return <DividerDoc />
  }
}

export default DividerView
