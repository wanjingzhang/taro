import React from 'react'
import TextareaDoc from '@md/textarea.md'

class TextareaView extends React.Component {
  render() {
    return <TextareaDoc />
  }
}

export default TextareaView
