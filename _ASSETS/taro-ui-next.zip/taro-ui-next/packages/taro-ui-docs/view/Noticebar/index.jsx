import React from 'react'
import NoticebarDoc from '@md/noticebar.md'

class NoticebarView extends React.Component {
  render() {
    return <NoticebarDoc />
  }
}

export default NoticebarView
