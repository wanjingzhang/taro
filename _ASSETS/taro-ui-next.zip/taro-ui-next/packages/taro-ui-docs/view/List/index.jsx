import React from 'react'
import ListDoc from '@md/list.md'

class ListView extends React.Component {
  render() {
    return <ListDoc />
  }
}

export default ListView
