import React from 'react'
import DrawerDoc from '@md/drawer.md'

class DrawerView extends React.Component {
  render() {
    return <DrawerDoc />
  }
}

export default DrawerView
