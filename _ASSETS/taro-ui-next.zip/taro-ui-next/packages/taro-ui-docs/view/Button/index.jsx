import React from 'react'
import ButtonDoc from '@md/button.md'

class ButtonView extends React.Component {
  render() {
    return <ButtonDoc />
  }
}

export default ButtonView
