import React from 'react'
import SearchBarDoc from '@md/search-bar.md'

class SearchBarView extends React.Component {
  render() {
    return <SearchBarDoc />
  }
}

export default SearchBarView
