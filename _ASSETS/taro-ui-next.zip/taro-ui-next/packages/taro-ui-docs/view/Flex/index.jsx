import React from 'react'
import FlexDoc from '@md/flex.md'

class ButtonView extends React.Component {
  render() {
    return <FlexDoc />
  }
}

export default ButtonView
