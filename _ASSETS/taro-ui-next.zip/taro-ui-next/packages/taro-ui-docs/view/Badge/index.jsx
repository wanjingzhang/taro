import React from 'react'
import BadgeDoc from '@md/badge.md'

class BadgeView extends React.Component {
  render() {
    return <BadgeDoc />
  }
}

export default BadgeView
