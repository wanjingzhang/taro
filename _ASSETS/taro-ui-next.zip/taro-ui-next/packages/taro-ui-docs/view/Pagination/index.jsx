import React from 'react'
import PaginationDoc from '@md/pagination.md'

class PaginationView extends React.Component {
  render() {
    return <PaginationDoc />
  }
}

export default PaginationView
