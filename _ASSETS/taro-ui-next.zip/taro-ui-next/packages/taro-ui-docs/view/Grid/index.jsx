import React from 'react'
import GridDoc from '@md/grid.md'

class ButtonView extends React.Component {
  render() {
    return <GridDoc />
  }
}

export default ButtonView
