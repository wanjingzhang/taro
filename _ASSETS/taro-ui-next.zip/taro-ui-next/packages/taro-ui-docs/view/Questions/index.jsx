import React from 'react'
import QuestionDoc from '@md/questions.md'

class QuestionsView extends React.Component {
  render() {
    return <QuestionDoc />
  }
}

export default QuestionsView
