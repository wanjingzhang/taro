import React from 'react'
import LoadMoreDoc from '@md/load-more.md'

class LoadMoreView extends React.Component {
  render() {
    return <LoadMoreDoc />
  }
}

export default LoadMoreView
