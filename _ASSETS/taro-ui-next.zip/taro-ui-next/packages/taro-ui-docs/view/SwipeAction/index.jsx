import React from 'react'
import SwipeActionDoc from '@md/swipe-action.md'

class SwipeActionView extends React.Component {
  render() {
    return <SwipeActionDoc />
  }
}

export default SwipeActionView
