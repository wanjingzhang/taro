import React from 'react'
import SegmentedControlDoc from '@md/segmented-control.md'

class SegmentedControlView extends React.Component {
  render() {
    return <SegmentedControlDoc />
  }
}

export default SegmentedControlView
