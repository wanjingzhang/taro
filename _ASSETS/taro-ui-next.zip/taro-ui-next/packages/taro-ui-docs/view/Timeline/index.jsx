import React from 'react'
import TimelineDoc from '@md/timeline.md'

class TimelineView extends React.Component {
  render() {
    return <TimelineDoc />
  }
}

export default TimelineView
