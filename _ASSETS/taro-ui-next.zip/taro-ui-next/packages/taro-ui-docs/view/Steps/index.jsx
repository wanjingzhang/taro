import React from 'react'
import StepsDoc from '@md/steps.md'

class StepsView extends React.Component {
  render() {
    return <StepsDoc />
  }
}

export default StepsView
