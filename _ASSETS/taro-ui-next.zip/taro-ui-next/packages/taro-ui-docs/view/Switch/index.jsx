import React from 'react'
import SwitchDoc from '@md/switch.md'

class SwitchView extends React.Component {
  render() {
    return <SwitchDoc />
  }
}

export default SwitchView
