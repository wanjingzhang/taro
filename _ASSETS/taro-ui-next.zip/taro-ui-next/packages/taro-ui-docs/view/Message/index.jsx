import React from 'react'
import MessageDoc from '@md/message.md'

class MessageView extends React.Component {
  render() {
    return <MessageDoc />
  }
}

export default MessageView
