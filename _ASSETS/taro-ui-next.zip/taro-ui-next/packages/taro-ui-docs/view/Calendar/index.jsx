import React from 'react'
import CalendarDoc from '@md/calendar.md'

class CalendarView extends React.Component {
  render() {
    return <CalendarDoc />
  }
}

export default CalendarView
