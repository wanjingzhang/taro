import React from 'react'
import CardDoc from '@md/card.md'

class ButtonView extends React.Component {
  render() {
    return <CardDoc />
  }
}

export default ButtonView
