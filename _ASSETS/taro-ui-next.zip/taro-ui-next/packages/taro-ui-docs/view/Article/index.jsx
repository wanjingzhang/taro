import React from 'react'
import ArticleDoc from '@md/article.md'

class ArticleView extends React.Component {
  render() {
    return <ArticleDoc />
  }
}

export default ArticleView
