import React from 'react'
import ModalDoc from '@md/modal.md'

class ModalView extends React.Component {
  render() {
    return <ModalDoc />
  }
}

export default ModalView
