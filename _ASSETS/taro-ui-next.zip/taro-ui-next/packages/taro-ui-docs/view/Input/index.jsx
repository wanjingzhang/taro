import React from 'react'
import InputDoc from '@md/input.md'

class InputView extends React.Component {
  render() {
    return <InputDoc />
  }
}

export default InputView
