import React from 'react'
import InputNumberDoc from '@md/input-number.md'

class InputNumberView extends React.Component {
  render() {
    return <InputNumberDoc />
  }
}

export default InputNumberView
