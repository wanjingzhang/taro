import React from 'react'
import TabsDoc from '@md/tabs.md'

class TabsView extends React.Component {
  render() {
    return <TabsDoc />
  }
}

export default TabsView
