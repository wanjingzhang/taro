# 设计资源

---

提供 `Taro-UI` 的视觉相关资源下载

<div class="at-resource">
  <div class="at-resource__item">
    <a href="https://storage.360buyimg.com/taro-resource/taro-ui/TaroUI.sketch.zip" class="flex flex-middle">
      <span class="at-resource__logo">
        <img src="https://storage.360buyimg.com/mtd/home/sketch1565263021806.png" />
      </span>
      <span class="at-resource__info">
        <span class="at-resource__info-title">Sketch Library</span>
        <span class="at-resource__info-desc">Taro UI 组件 Sketch 视觉稿</span>
      </span>
    </a>
  </div>

  <div class="at-resource__item">
    <a href="http://storage.360buyimg.com/mtd/home/taroui-rplib1565263474229.zip" class="flex flex-middle">
      <span class="at-resource__logo">
        <img src="https://storage.360buyimg.com/mtd/home/axure31565263422240.png" />
      </span>
      <span class="at-resource__info">
        <span class="at-resource__info-title">Axure Library</span>
        <span class="at-resource__info-desc">Taro UI 组件的 Axure 部件库</span>
      </span>
    </a>
  </div>
</div>
