export default {
  navigationBarTitleText: 'Taro UI'
}
