# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## 3.0.1 (2020-04-18)

**Note:** Version bump only for package taro-ui-demo
